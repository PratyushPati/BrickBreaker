using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class brick : MonoBehaviour
{
    public GameObject effect;
    public void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ball"))
        {
            Instantiate(effect, transform.position, Quaternion.identity);
            gameObject.SetActive(false);
        }
        
    }
}
