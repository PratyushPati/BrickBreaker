using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using EZCameraShake;
using TMPro;

public class ball : MonoBehaviour
{
    public Rigidbody2D rb;
    public float speed = 10f; 
    public float Rspeed = 250f;
    public TMP_Text scoreDisplay;
    public TMP_Text HighscoreDisplay;
    public int score = 0;
    public GameObject gameover;
    public int lives = 3;
    public Image first;
    public Image second;
    public Image third;
    public TrailRenderer tr;
    public player player;
    private int c = 0;


    //ball movement
    void ballmovement()
    {
        //tr.enabled = true;
        Vector2 force = Vector2.zero;
        force.x = Random.Range(-1f, 1f);
        force.y = -1f;
        rb.AddForce(force.normalized * speed);
    }


    void Start()
    {
        HighscoreDisplay.text = PlayerPrefs.GetInt("HighScore" + SceneManager.GetActiveScene().name, 0).ToString();
        Resetball();
        PlayerPrefs.SetInt("level",SceneManager.GetActiveScene().buildIndex);
    }


    private void FixedUpdate()
    {
        rb.velocity = Rspeed * (rb.velocity.normalized)*Time.deltaTime;
        if (SceneManager.GetActiveScene().name == "level1" && score == 42)
        {
            SceneManager.LoadScene("nextlevel");
        }
        if (SceneManager.GetActiveScene().name == "level2" && score == 46)
        {
            SceneManager.LoadScene("nextlevel");
        }
        if (SceneManager.GetActiveScene().name == "level3" && score == 49)
        {
            SceneManager.LoadScene("nextlevel");
        }
        if (SceneManager.GetActiveScene().name == "level4" && score == 60)
        {
            SceneManager.LoadScene("nextlevel");
        }
        if (SceneManager.GetActiveScene().name == "level5" && score == 45)
        {
            SceneManager.LoadScene("nextlevel");
        }
        if (SceneManager.GetActiveScene().name == "level6" && score == 41)
        {
            SceneManager.LoadScene("nextlevel");
        }
        if (SceneManager.GetActiveScene().name == "level7" && score == 36)
        {
            SceneManager.LoadScene("nextlevel");
        }
        if (SceneManager.GetActiveScene().name == "level8" && score == 38)
        {
            SceneManager.LoadScene("nextlevel");
        }
        if (SceneManager.GetActiveScene().name == "level9" && score == 34)
        {
            SceneManager.LoadScene("nextlevel");
        }
        if (SceneManager.GetActiveScene().name == "level10" && score == 43)
        {
            SceneManager.LoadScene("nextlevel");
        }
    }


    //Score System
    public void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("brick"))
        {
            score++;
            c++;
            scoreDisplay.text = score.ToString();

            if (score > PlayerPrefs.GetInt("HighScore" + SceneManager.GetActiveScene().name, 0))
            {
                PlayerPrefs.SetInt("HighScore" + SceneManager.GetActiveScene().name, score);
                HighscoreDisplay.text = score.ToString();
            }
        }
        PlayerPrefs.SetInt("SCORE", score);
    }

    //lives system
    private void OnTriggerEnter2D(Collider2D collision)
    {
        
        if (collision.CompareTag("bottom"))
        {
            CameraShaker.Instance.ShakeOnce(2f, 1f, .25f, 1f);
            lives--;
            if (lives == 3)
            {
                first.enabled = true;
                second.enabled = true;
                third.enabled = true;
            }
            if (lives == 2)
            {
                first.enabled = true;
                second.enabled = true;
                third.enabled = false;
            }
            if (lives == 1)
            {
                first.enabled = true;
                second.enabled = false;
                third.enabled = false;
            }
            if (lives == 0)
            {
                first.enabled = false;
                second.enabled = false;
                third.enabled = false;
            }
            if (lives <= 0)
            {
                SceneManager.LoadScene("nextlevel");
            }
            Resetball();
            player.resetplayer();
        }
    }
    public void levelcomplete()
    {
        Debug.Log(SceneManager.GetActiveScene().name == "level1");
    }

    //Reset ball and player posiiton
    public void Resetball()
    {
       // tr.enabled = false;
        transform.position = new Vector2(-1.83f,-3.59f);
        rb.velocity = Vector2.zero;
        Invoke(nameof(ballmovement), 1f);
    }
}
