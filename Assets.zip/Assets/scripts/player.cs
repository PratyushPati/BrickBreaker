using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class player : MonoBehaviour
{
    public float hspeed = 15f;
    private Rigidbody2D rb;
    public float clampwidthL = 5f;
    public float clampwidthR = 5f;
    public float maxBounceAngle=74f;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void FixedUpdate()
    {
        float x = Input.GetAxis("Horizontal") * Time.deltaTime * hspeed;
        Vector2 newpos = rb.position + Vector2.right * x;
        newpos.x = Mathf.Clamp(newpos.x, -clampwidthL, clampwidthR);
        rb.MovePosition(newpos);
    }
    private void LateUpdate()
    {
        if (Input.GetMouseButton(0))
        {
            Vector2 curPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            transform.position = new Vector2(curPos.x, transform.position.y);
            curPos.x = Mathf.Clamp(curPos.x, -clampwidthL, clampwidthR);
        }
        else
        {
            rb.velocity = Vector2.zero;
        }
    }


    //Better movement
    private void OnCollisionEnter2D(Collision2D collision)
    {
        ball ball = collision.gameObject.GetComponent<ball>();

        if (ball != null)
        {
            Vector2 paddelPosition = transform.position;
            Vector2 contactPosiion = collision.GetContact(0).point;

            float offset = paddelPosition.x - contactPosiion.x;
            float maxoffset = collision.otherCollider.bounds.size.x / 2;

            float currentangle = Vector2.SignedAngle(Vector2.up, ball.rb.velocity);
            float bounceangle = (offset / maxoffset) * maxBounceAngle;
            float newangle = Mathf.Clamp(currentangle + bounceangle, -maxBounceAngle, maxBounceAngle);

            Quaternion rotation = Quaternion.AngleAxis(newangle, Vector3.forward);
            ball.rb.velocity = rotation * Vector2.up * ball.rb.velocity.magnitude;
        }
    }


    //reset player position
    public void resetplayer()
    {
        transform.position = new Vector2(-1.83f, transform.position.y);
        rb.velocity = Vector2.zero;
    }

}

