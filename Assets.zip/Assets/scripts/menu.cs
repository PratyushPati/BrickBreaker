using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;

public class menu : MonoBehaviour
{
    [SerializeField] GameObject pausemenu;
    public Text score;
    public Text highscore1;

    public void Gpause()
    {
        pausemenu.SetActive(true);
        Time.timeScale = 0f;
    }
    public void Gplay()
    {
        SceneManager.LoadScene("level1");
    }
    public void Gselectlevel()
    {
        SceneManager.LoadScene("selectlevel");
    }
    public void Gresume()
    {
        pausemenu.SetActive(false);
        Time.timeScale = 1f;
    }
    public void Ghome()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("start");
    }
    public void Grestart()
    {
        Time.timeScale = 1f;
        Invoke(nameof(gameRestart),1.0f);
    }
    public void gameRestart()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
    public void Gquit()
    {
        Debug.Log("QUIT");
        Application.Quit();
    }
    public void Glevel()
    {
        string levelname= EventSystem.current.currentSelectedGameObject.name;
        SceneManager.LoadScene(levelname);
    }
    public void Gnextlevel()
    {
        int nextlevel = PlayerPrefs.GetInt("level", SceneManager.GetActiveScene().buildIndex) ;
        string nextlevelname = "level" + nextlevel.ToString();
        SceneManager.LoadScene(nextlevelname);
    }
    public void Gretry()
    {
        int nextlevel = PlayerPrefs.GetInt("level", SceneManager.GetActiveScene().buildIndex)-1;
        string nextlevelname = "level" + nextlevel.ToString();
        SceneManager.LoadScene(nextlevelname);
    }

    //score and highscore
    private void Start()
    {
        int nextlevel = PlayerPrefs.GetInt("level", SceneManager.GetActiveScene().buildIndex)-1;
        string highscore = "level" + nextlevel.ToString();
        score.text = PlayerPrefs.GetInt("SCORE").ToString();
        highscore1.text = PlayerPrefs.GetInt("HighScore" + highscore).ToString();
    }

  
}
